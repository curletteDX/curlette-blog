import Link from "next/link"
import { ArrowUpRight } from "lucide-react"

interface BlogPostCardProps {
  title: string
  description: string
  category: string
  readTime: string
  slug: string
  date?: string
}

export function BlogPostCard({ title, description, category, readTime, slug, date }: BlogPostCardProps) {
  return (
    <article className="group">
      <Link href={`/writing/${slug}`} className="block space-y-4">
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="rounded-full bg-secondary px-3 py-1 font-medium">{category}</span>
          <span>{readTime}</span>
          {date && <span>{date}</span>}
        </div>
        <h3 className="text-2xl font-medium tracking-tight transition-colors group-hover:text-primary text-balance">
          {title}
        </h3>
        <p className="text-muted-foreground leading-relaxed">{description}</p>
        <div className="flex items-center gap-1 text-sm font-medium text-primary opacity-0 transition-opacity group-hover:opacity-100">
          Read article
          <ArrowUpRight className="h-4 w-4" />
        </div>
      </Link>
    </article>
  )
}
