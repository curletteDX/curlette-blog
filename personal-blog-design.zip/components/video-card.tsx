import { Play } from "lucide-react"

interface VideoCardProps {
  title: string
  platform: string
  duration: string
  thumbnail: string
  url?: string
}

export function VideoCard({ title, platform, duration, thumbnail, url = "#" }: VideoCardProps) {
  return (
    <article className="group">
      <a href={url} target="_blank" rel="noopener noreferrer" className="block space-y-4">
        <div className="relative aspect-video overflow-hidden rounded-lg border border-border/50 bg-muted">
          <img
            src={thumbnail || "/placeholder.svg"}
            alt={title}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute inset-0 flex items-center justify-center bg-black/20 opacity-0 transition-opacity group-hover:opacity-100">
            <div className="flex h-16 w-16 items-center justify-center rounded-full bg-white/90 backdrop-blur-sm">
              <Play className="h-6 w-6 fill-primary text-primary" />
            </div>
          </div>
          <div className="absolute bottom-2 right-2 rounded bg-black/80 px-2 py-1 text-xs text-white">{duration}</div>
        </div>
        <div className="space-y-2">
          <p className="text-xs text-muted-foreground">{platform}</p>
          <h3 className="font-medium leading-snug transition-colors group-hover:text-primary text-balance">{title}</h3>
        </div>
      </a>
    </article>
  )
}
