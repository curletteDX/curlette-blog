import Link from "next/link"
import { ArrowLeft, Calendar } from "lucide-react"
import Image from "next/image"

export default function BlogPost() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header Navigation */}
      <header className="border-b border-border/40 bg-background/80 backdrop-blur-sm sticky top-0 z-10">
        <div className="mx-auto max-w-5xl px-6 py-4">
          <Link
            href="/"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary group"
          >
            <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
            Back to home
          </Link>
        </div>
      </header>

      {/* Article */}
      <article className="mx-auto max-w-3xl px-6">
        {/* Article Header */}
        <header className="py-12 md:py-16 space-y-6">
          {/* Category Badge */}
          <div className="inline-flex items-center gap-2">
            <span className="rounded-full bg-secondary px-3 py-1.5 text-xs font-medium uppercase tracking-wider text-secondary-foreground">
              Development
            </span>
          </div>

          {/* Title */}
          <h1 className="text-4xl font-medium tracking-tight text-balance md:text-5xl lg:text-6xl leading-[1.1]">
            The Art of Composable Architecture
          </h1>

          {/* Meta Info */}
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="h-4 w-4" />
              December 7, 2024
            </div>
          </div>

          {/* Hero Image */}
          <div className="!mt-8 overflow-hidden rounded-lg">
            <Image
              src="/react-code-editor.jpg"
              alt="Code editor showing composable architecture"
              width={1200}
              height={630}
              className="w-full"
            />
          </div>

          {/* Excerpt/Lede */}
          <p className="!mt-8 text-xl leading-relaxed text-muted-foreground text-pretty">
            Exploring how composable systems enable flexibility and scalability in modern web development. Learn the
            principles and patterns that make architectures truly maintainable.
          </p>
        </header>

        {/* Article Content */}
        <div className="prose prose-slate max-w-none pb-16">
          {/* Introduction */}
          <div className="mb-10 space-y-5 text-foreground/90 leading-relaxed text-[17px]">
            <p>
              In the ever-evolving landscape of web development, the concept of composable architecture has emerged as a
              fundamental principle for building scalable, maintainable systems. But what does it really mean to build
              composable software, and why should we care?
            </p>
            <p>
              At its core, composable architecture is about breaking down complex systems into smaller, reusable pieces
              that can be combined in different ways. Think of it like LEGO blocks—each piece has a specific purpose,
              but the real magic happens when you start connecting them together.
            </p>
          </div>

          {/* Section Heading */}
          <h2 className="text-3xl font-medium tracking-tight text-foreground mb-6 mt-12">
            The Principles of Composability
          </h2>

          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            Building composable systems requires adherence to several key principles that ensure your components remain
            flexible and maintainable over time. Let's explore the most important ones:
          </p>

          {/* Subsection */}
          <h3 className="text-2xl font-medium text-foreground mb-4 mt-8">Single Responsibility</h3>
          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            Each component should do one thing and do it well. This principle, borrowed from UNIX philosophy, ensures
            that your components remain focused and easy to reason about. When a component has a single, well-defined
            purpose, it becomes easier to test, debug, and reuse.
          </p>

          <h3 className="text-2xl font-medium text-foreground mb-4 mt-8">Clear Interfaces</h3>
          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            Components should expose clear, well-documented APIs. The contract between components should be explicit,
            making it easy to understand how pieces fit together without diving into implementation details.
          </p>

          {/* Image with Caption */}
          <figure className="my-10">
            <div className="overflow-hidden rounded-lg">
              <Image
                src="/flute-music-performance.jpg"
                alt="Musical performance demonstrating rhythm and patterns"
                width={1200}
                height={675}
                className="w-full"
              />
            </div>
            <figcaption className="mt-3 text-sm text-muted-foreground text-center">
              Like musical composition, software architecture relies on patterns, rhythm, and harmony between
              components.
            </figcaption>
          </figure>

          {/* Code Example Section */}
          <h2 className="text-3xl font-medium tracking-tight text-foreground mb-6 mt-12">A Practical Example</h2>

          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            Let's look at a simple example of composable React components. Here's how we might build a flexible card
            system that demonstrates these principles in action:
          </p>

          {/* Code Block */}
          <div className="my-8 relative rounded-lg border border-border/50 bg-muted/30 overflow-hidden">
            <div className="flex items-center justify-between border-b border-border/40 bg-muted/60 px-4 py-2.5">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">TypeScript</span>
            </div>
            <pre className="p-5 overflow-x-auto text-[15px] leading-relaxed">
              <code className="font-mono text-foreground/90">
                {`// Base Card component
interface CardProps {
  children: React.ReactNode
  className?: string
}

export function Card({ children, className }: CardProps) {
  return (
    <div className={\`rounded-lg border p-6 \${className}\`}>
      {children}
    </div>
  )
}

// Composable sub-components
Card.Header = function CardHeader({ 
  children 
}: { 
  children: React.ReactNode 
}) {
  return (
    <div className="mb-4 text-2xl font-medium">
      {children}
    </div>
  )
}

Card.Content = function CardContent({ 
  children 
}: { 
  children: React.ReactNode 
}) {
  return (
    <div className="text-muted-foreground">
      {children}
    </div>
  )
}

// Usage example
<Card>
  <Card.Header>Welcome</Card.Header>
  <Card.Content>
    This is a composable card system.
  </Card.Content>
</Card>`}
              </code>
            </pre>
          </div>

          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            This pattern gives you the flexibility to compose cards in different ways while maintaining a consistent
            API. You can add or remove sections as needed without breaking the component's contract.
          </p>

          {/* Blockquote */}
          <blockquote className="my-10 border-l-4 border-primary pl-6 py-2 italic text-lg text-foreground/80 leading-relaxed">
            "Simplicity is the ultimate sophistication. In software architecture, this means building systems from
            simple, composable pieces rather than complex, monolithic structures."
          </blockquote>

          {/* Another Section */}
          <h2 className="text-3xl font-medium tracking-tight text-foreground mb-6 mt-12">Real-World Benefits</h2>

          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            When you embrace composable architecture, you unlock several tangible benefits that directly impact your
            development workflow and product quality.
          </p>

          {/* Bullet List */}
          <ul className="space-y-3 my-6 pl-6">
            <li className="text-foreground/90 leading-relaxed text-[17px]">
              <strong className="text-foreground">Faster Development:</strong> Reusable components mean you're not
              reinventing the wheel for every feature.
            </li>
            <li className="text-foreground/90 leading-relaxed text-[17px]">
              <strong className="text-foreground">Easier Testing:</strong> Small, focused components are simpler to test
              in isolation.
            </li>
            <li className="text-foreground/90 leading-relaxed text-[17px]">
              <strong className="text-foreground">Better Collaboration:</strong> Clear boundaries make it easier for
              teams to work in parallel without stepping on each other's toes.
            </li>
            <li className="text-foreground/90 leading-relaxed text-[17px]">
              <strong className="text-foreground">Scalable Architecture:</strong> Adding new features doesn't require
              massive refactoring of existing code.
            </li>
          </ul>

          <h2 className="text-3xl font-medium tracking-tight text-foreground mb-6 mt-12">Moving Forward</h2>

          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            Composable architecture isn't just a technical pattern—it's a mindset shift. It requires thinking about your
            system as a collection of independent, reusable parts rather than a monolithic whole.
          </p>

          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            Start small. Identify repetitive patterns in your codebase and extract them into composable components. Over
            time, you'll build a library of reusable pieces that make development faster and more enjoyable.
          </p>

          <p className="mb-5 text-foreground/90 leading-relaxed text-[17px]">
            The journey to composable architecture is iterative. Each small improvement compounds over time, leading to
            a more maintainable and flexible system. Your future self will thank you for the time invested in building
            these foundations.
          </p>
        </div>
      </article>

      {/* Suggested Reading */}
      <div className="border-t border-border/40 bg-muted/20 py-16">
        <div className="mx-auto max-w-5xl px-6">
          <h2 className="text-2xl font-medium mb-8">Continue Reading</h2>
          <div className="grid gap-6 md:grid-cols-3">
            <Link
              href="/writing/mindful-coding"
              className="group rounded-lg border border-border/50 bg-background p-6 transition-all hover:border-primary/50 hover:shadow-lg"
            >
              <div className="mb-3 inline-block rounded-full bg-secondary px-2.5 py-1 text-xs font-medium uppercase tracking-wider text-secondary-foreground">
                Mindfulness
              </div>
              <h3 className="text-lg font-medium mb-2 group-hover:text-primary transition-colors">
                Mindful Coding Practices
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Bringing awareness and intention to your development workflow.
              </p>
            </Link>

            <Link
              href="/writing/flute-and-flow"
              className="group rounded-lg border border-border/50 bg-background p-6 transition-all hover:border-primary/50 hover:shadow-lg"
            >
              <div className="mb-3 inline-block rounded-full bg-secondary px-2.5 py-1 text-xs font-medium uppercase tracking-wider text-secondary-foreground">
                Music
              </div>
              <h3 className="text-lg font-medium mb-2 group-hover:text-primary transition-colors">
                Flute Playing and Flow State
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                How musical practice teaches us about deep work and focus.
              </p>
            </Link>

            <Link
              href="/writing/component-design"
              className="group rounded-lg border border-border/50 bg-background p-6 transition-all hover:border-primary/50 hover:shadow-lg"
            >
              <div className="mb-3 inline-block rounded-full bg-secondary px-2.5 py-1 text-xs font-medium uppercase tracking-wider text-secondary-foreground">
                Development
              </div>
              <h3 className="text-lg font-medium mb-2 group-hover:text-primary transition-colors">
                Component Design Patterns
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Essential patterns for building reusable React components.
              </p>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
