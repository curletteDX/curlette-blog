import { ArrowUpRight } from "lucide-react"
import Link from "next/link"

// Sample blog posts - replace with your actual content
const blogPosts = [
  {
    title: "The Art of Composable Architecture",
    description: "Exploring how composable systems enable flexibility and scalability in modern web development.",
    category: "Development",
    readTime: "8 min read",
    slug: "composable-architecture",
    date: "Dec 2024",
  },
  {
    title: "Mindful Coding: Finding Flow State",
    description: "How mindfulness practices can improve focus, reduce burnout, and enhance creative problem-solving.",
    category: "Mindfulness",
    readTime: "6 min read",
    slug: "mindful-coding",
    date: "Nov 2024",
  },
  {
    title: "The Intersection of Music and Code",
    description: "Patterns, rhythm, and structure: what flute performance teaches us about elegant software design.",
    category: "Music",
    readTime: "5 min read",
    slug: "music-and-code",
    date: "Nov 2024",
  },
]

const latestArticles = [
  {
    title: "The Art of Composable Architecture",
    description: "Exploring how composable systems enable flexibility and scalability in modern web development.",
    category: "Development",
    readTime: "8 min read",
    slug: "composable-architecture",
    date: "Dec 2024",
  },
  {
    title: "Mindful Coding: Finding Flow State",
    description: "How mindfulness practices can improve focus, reduce burnout, and enhance creative problem-solving.",
    category: "Mindfulness",
    readTime: "6 min read",
    slug: "mindful-coding",
    date: "Nov 2024",
  },
  {
    title: "The Intersection of Music and Code",
    description: "Patterns, rhythm, and structure: what flute performance teaches us about elegant software design.",
    category: "Music",
    readTime: "5 min read",
    slug: "music-and-code",
    date: "Nov 2024",
  },
  {
    title: "Headless CMS and the Future of Content",
    description: "Why decoupling your content from presentation unlocks new possibilities for multi-channel delivery.",
    category: "Development",
    readTime: "10 min read",
    slug: "headless-cms-future",
    date: "Oct 2024",
  },
  {
    title: "Breathing Techniques for Developers",
    description: "Simple breath work exercises to reduce stress and improve concentration during long coding sessions.",
    category: "Mindfulness",
    readTime: "4 min read",
    slug: "breathing-techniques",
    date: "Oct 2024",
  },
  {
    title: "Bach's Influence on Modern Music",
    description: "How baroque composition principles still shape contemporary musical arrangements and improvisation.",
    category: "Music",
    readTime: "7 min read",
    slug: "bach-modern-music",
    date: "Sep 2024",
  },
  {
    title: "Building Design Systems That Scale",
    description: "Lessons learned from creating component libraries that grow with your team and product.",
    category: "Development",
    readTime: "12 min read",
    slug: "design-systems-scale",
    date: "Sep 2024",
  },
  {
    title: "Walking Meditation for Creative Thinking",
    description: "How movement and mindfulness combine to unlock creative solutions to difficult problems.",
    category: "Mindfulness",
    readTime: "5 min read",
    slug: "walking-meditation",
    date: "Aug 2024",
  },
  {
    title: "The Physics of Flute Tone",
    description: "Understanding acoustic principles to improve your embouchure and sound production.",
    category: "Music",
    readTime: "9 min read",
    slug: "flute-tone-physics",
    date: "Aug 2024",
  },
  {
    title: "API Design Patterns for Modern Apps",
    description: "Best practices for building RESTful and GraphQL APIs that developers love to use.",
    category: "Development",
    readTime: "11 min read",
    slug: "api-design-patterns",
    date: "Jul 2024",
  },
]

const videos = [
  {
    title: "Building Composable Components in React",
    platform: "YouTube",
    duration: "18:42",
    thumbnail: "/react-code-editor.jpg",
  },
  {
    title: "Morning Flute Practice: Bach Sonata",
    platform: "YouTube",
    duration: "12:15",
    thumbnail: "/flute-music-performance.jpg",
  },
]

export default function Home() {
  return (
    <div className="min-h-screen">
      <header className="relative border-b border-border/40 overflow-hidden">
        {/* Art Deco geometric accent */}
        <div className="absolute right-0 top-0 h-full w-1/3 opacity-[0.03]">
          <div className="absolute right-0 top-0 h-32 w-32 rotate-45 bg-primary" />
          <div className="absolute right-16 top-16 h-24 w-24 rotate-45 bg-accent" />
        </div>

        <div className="mx-auto max-w-6xl px-6 py-8 md:py-12 relative">
          <nav className="mb-12 flex items-center justify-between">
            <Link href="/" className="text-lg font-medium tracking-tight relative group">
              <span className="relative z-10">Curlette</span>
              <div className="absolute inset-0 -z-10 bg-primary/5 scale-0 group-hover:scale-100 transition-transform rounded-md -m-2" />
            </Link>
            <div className="flex items-center gap-8">
              <Link
                href="/writing"
                className="text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
              >
                Writing
              </Link>
              <Link
                href="/videos"
                className="text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
              >
                Videos
              </Link>
              <Link
                href="/about"
                className="text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
              >
                About
              </Link>
            </div>
          </nav>

          <div className="space-y-6">
            <h1 className="text-4xl font-medium tracking-tight text-balance md:text-5xl lg:text-6xl leading-[1.1]">
              Curlette
            </h1>
            <div className="h-1 w-16 bg-gradient-to-r from-primary to-accent rounded-full" />
            <p className="max-w-2xl text-base leading-relaxed text-muted-foreground md:text-lg text-pretty">
              I write about composable development, mindfulness practices, and flute music. Exploring the intersection
              of technology, consciousness, and creative expression.
            </p>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8 md:py-12">
        <section className="mb-12 space-y-8">
          <div className="flex items-baseline justify-between border-b border-border/40 pb-3">
            <h2 className="text-2xl font-medium tracking-tight">Latest Writing</h2>
            <Link
              href="/writing"
              className="group flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
            >
              View all
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {blogPosts.map((post, idx) => (
              <article key={post.slug} className="group relative">
                {/* Subtle art deco line accent on hover */}
                <div className="absolute -left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary/50 to-accent/50 scale-y-0 group-hover:scale-y-100 transition-transform origin-top rounded-full" />

                <Link href={`/writing/${post.slug}`} className="block space-y-3">
                  <div className="flex items-center gap-2 text-xs flex-wrap">
                    <span className="rounded-full bg-secondary px-2.5 py-1 font-medium text-secondary-foreground transition-colors group-hover:bg-primary/10 group-hover:text-primary">
                      {post.category}
                    </span>
                    <span className="text-muted-foreground">{post.readTime}</span>
                  </div>
                  <h3 className="text-lg font-medium tracking-tight transition-colors group-hover:text-primary text-balance leading-snug">
                    {post.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed text-pretty line-clamp-3">
                    {post.description}
                  </p>
                  <div className="flex items-center gap-1.5 text-xs font-medium text-primary opacity-0 transition-opacity group-hover:opacity-100">
                    Read article
                    <ArrowUpRight className="h-3 w-3" />
                  </div>
                </Link>
              </article>
            ))}
          </div>
        </section>

        <section className="mb-12 space-y-8">
          <div className="flex items-baseline justify-between border-b border-border/40 pb-3">
            <h2 className="text-2xl font-medium tracking-tight">Featured Videos</h2>
            <Link
              href="/videos"
              className="group flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
            >
              View all
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {videos.map((video, index) => (
              <article key={index} className="group space-y-3">
                <div className="relative aspect-video overflow-hidden rounded-lg border border-border/50 bg-muted ring-1 ring-transparent transition-all group-hover:ring-primary/20 group-hover:border-primary/40">
                  <img
                    src={video.thumbnail || "/placeholder.svg"}
                    alt={video.title}
                    className="h-full w-full object-cover transition-all duration-500 group-hover:scale-105 group-hover:brightness-95"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute bottom-3 right-3 rounded bg-black/90 px-2.5 py-1.5 text-xs font-medium text-white backdrop-blur-sm">
                    {video.duration}
                  </div>
                  {/* Play button overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="rounded-full bg-white/90 p-4 backdrop-blur-sm">
                      <svg className="h-6 w-6 text-primary" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M8 5v14l11-7z" />
                      </svg>
                    </div>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <p className="text-xs text-muted-foreground font-medium">{video.platform}</p>
                  <h3 className="font-medium leading-snug transition-colors group-hover:text-primary text-balance">
                    {video.title}
                  </h3>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="mb-12 space-y-8">
          <div className="flex items-baseline justify-between border-b border-border/40 pb-3">
            <h2 className="text-2xl font-medium tracking-tight">All Articles</h2>
            <Link
              href="/writing"
              className="group flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
            >
              View all
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
          </div>

          <div className="space-y-4">
            {latestArticles.map((post, idx) => (
              <article
                key={post.slug}
                className="group relative border-b border-border/40 pb-4 last:border-0 last:pb-0"
              >
                {/* Hover accent line */}
                <div className="absolute -left-6 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary/50 to-accent/50 scale-y-0 group-hover:scale-y-100 transition-transform origin-top rounded-full" />

                <Link href={`/writing/${post.slug}`} className="block">
                  <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between md:gap-6">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-3 flex-wrap">
                        <h3 className="text-lg font-medium tracking-tight transition-colors group-hover:text-primary text-balance leading-snug">
                          {post.title}
                        </h3>
                        <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium text-secondary-foreground transition-colors group-hover:bg-primary/10 group-hover:text-primary">
                          {post.category}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed text-pretty line-clamp-2">
                        {post.description}
                      </p>
                    </div>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground md:flex-col md:items-end md:gap-1">
                      <span className="font-medium">{post.date}</span>
                      <span>{post.readTime}</span>
                    </div>
                  </div>
                </Link>
              </article>
            ))}
          </div>
        </section>

        <section className="space-y-6 border-t border-border/40 pt-12 relative">
          <div className="absolute -top-px left-0 h-px w-24 bg-gradient-to-r from-primary to-transparent" />
          <h2 className="text-2xl font-medium tracking-tight">About</h2>
          <div className="space-y-4 text-muted-foreground leading-relaxed text-pretty">
            <p>
              I'm a developer passionate about building composable, modular systems that enable creativity and
              flexibility. My work explores how thoughtful architecture and mindful practice can lead to better software
              and better experiences.
            </p>
            <p>
              When I'm not writing code, I practice mindfulness meditation and play the flute. I believe these
              disciplines inform each other—pattern recognition, breath control, and presence are essential to all
              three.
            </p>
            <Link
              href="/about"
              className="inline-flex items-center gap-1.5 text-foreground font-medium transition-colors hover:text-primary group"
            >
              Read more about me
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
          </div>
        </section>
      </main>

      <footer className="border-t border-border/40 bg-muted/30">
        <div className="mx-auto max-w-6xl px-6 py-12">
          <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
            <div className="space-y-2">
              <p className="text-sm font-medium">Curlette</p>
              <p className="text-sm text-muted-foreground">Composable development, mindfulness & music</p>
            </div>
            <div className="flex items-center gap-6">
              <Link
                href="https://github.com"
                className="text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
              >
                GitHub
              </Link>
              <Link
                href="https://twitter.com"
                className="text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
              >
                Twitter
              </Link>
              <Link
                href="https://youtube.com"
                className="text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
              >
                YouTube
              </Link>
              <Link
                href="/rss"
                className="text-sm text-muted-foreground transition-colors hover:text-primary font-medium"
              >
                RSS
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
